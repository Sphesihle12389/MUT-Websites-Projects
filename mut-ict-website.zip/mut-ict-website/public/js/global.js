// global.js - Global Functions for All Pages

// Check if user is logged in
function checkAuth() {
    const user = sessionStorage.getItem("mut_auth_user");
    if (!user) {
        window.location.href = "login.html";
        return false;
    }
    return true;
}

// Logout function
function setupLogout() {
    const logoutBtn = document.getElementById("logoutBtn");
    if (logoutBtn) {
        logoutBtn.onclick = () => {
            sessionStorage.removeItem("mut_auth_user");
            window.location.href = "login.html";
        };
    }
}

// Load profile picture into sidebar
function loadProfilePicture() {
    const user = sessionStorage.getItem("mut_auth_user");
    if (!user) return;

    const userData = JSON.parse(user);
    if (userData.isGuest) return;

    const savedImage = localStorage.getItem(`profile_${userData.email}`);
    const sidebarLogoDiv = document.querySelector('.sidebar-logo div');

    if (sidebarLogoDiv && savedImage) {
        sidebarLogoDiv.innerHTML = `<img src="${savedImage}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">`;
        sidebarLogoDiv.style.padding = '0';
        sidebarLogoDiv.style.overflow = 'hidden';
        sidebarLogoDiv.style.display = 'flex';
        sidebarLogoDiv.style.alignItems = 'center';
        sidebarLogoDiv.style.justifyContent = 'center';
        sidebarLogoDiv.style.background = 'none';
    }
}

// Display user name
function displayUserName() {
    const user = sessionStorage.getItem("mut_auth_user");
    const userNameSpan = document.getElementById("userNameDisplay");
    if (userNameSpan) {
        if (user) {
            const userData = JSON.parse(user);
            if (userData.isGuest) {
                userNameSpan.innerText = "Guest User";
            } else {
                userNameSpan.innerText = userData.name || userData.email.split('@')[0];
            }
        }
    }
}

// Load top bar avatar
function loadTopBarAvatar() {
    const user = sessionStorage.getItem("mut_auth_user");
    if (!user) return;

    const userData = JSON.parse(user);
    if (userData.isGuest) return;

    const savedImage = localStorage.getItem(`profile_${userData.email}`);
    const topBarAvatar = document.getElementById('topBarAvatar');
    if (topBarAvatar && savedImage) {
        topBarAvatar.src = savedImage;
        topBarAvatar.style.display = 'block';
    }
}

// Initialize all global functions
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById("logoutBtn")) {
        setupLogout();
    }
    loadProfilePicture();
    displayUserName();
    loadTopBarAvatar();
});