// profile.js - Profile Page Functions

let originalImage = null;
let currentFilter = 'original';
let currentWidth = 150;
let currentHeight = 150;
let userData = null;

const user = sessionStorage.getItem("mut_auth_user");
if (user) {
    userData = JSON.parse(user);
    document.getElementById("userNameDisplay").innerText = userData.name || userData.email.split('@')[0];
    document.getElementById("profileNameDisplay").innerText = userData.name || userData.email.split('@')[0];
    document.getElementById("userEmailDisplay").innerText = userData.email;
    document.getElementById("userPhoneDisplay").innerText = userData.phone || "+27 63 885 5903";
}

const originalCanvas = document.getElementById('originalCanvas');
const previewCanvas = document.getElementById('previewCanvas');
const profileCanvas = document.getElementById('profileCanvas');
const originalCtx = originalCanvas.getContext('2d');
const previewCtx = previewCanvas.getContext('2d');
const profileCtx = profileCanvas.getContext('2d');

function resizeImageToFit(img, targetWidth, targetHeight) {
    const imgWidth = img.width;
    const imgHeight = img.height;
    const imgAspect = imgWidth / imgHeight;
    const targetAspect = targetWidth / targetHeight;

    let drawWidth, drawHeight, offsetX = 0, offsetY = 0;

    if (imgAspect > targetAspect) {
        drawHeight = targetHeight;
        drawWidth = imgWidth * (targetHeight / imgHeight);
        offsetX = (targetWidth - drawWidth) / 2;
    } else {
        drawWidth = targetWidth;
        drawHeight = imgHeight * (targetWidth / imgWidth);
        offsetY = (targetHeight - drawHeight) / 2;
    }

    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = targetWidth;
    tempCanvas.height = targetHeight;
    const tempCtx = tempCanvas.getContext('2d');
    tempCtx.fillStyle = '#2d3a4e';
    tempCtx.fillRect(0, 0, targetWidth, targetHeight);
    tempCtx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);
    return tempCanvas;
}

function loadSavedProfilePicture() {
    const savedImage = localStorage.getItem(`profile_${userData.email}`);
    if (savedImage) {
        const img = new Image();
        img.onload = function () {
            originalImage = img;
            originalCanvas.width = img.width;
            originalCanvas.height = img.height;
            originalCtx.drawImage(img, 0, 0);

            const resizedCanvas = resizeImageToFit(img, 150, 150);
            profileCanvas.width = 150;
            profileCanvas.height = 150;
            profileCtx.drawImage(resizedCanvas, 0, 0);
        };
        img.src = savedImage;
    } else {
        profileCtx.fillStyle = '#6B1C20';
        profileCtx.fillRect(0, 0, 150, 150);
        profileCtx.fillStyle = '#C9962A';
        profileCtx.font = 'bold 16px "Segoe UI"';
        profileCtx.fillText('MUT', 55, 85);
    }
}

function updatePreview() {
    if (!originalImage) return;
    const resizedCanvas = resizeImageToFit(originalImage, currentWidth, currentHeight);

    if (currentFilter !== 'original' && currentFilter !== 'reset') {
        const tempCtx = resizedCanvas.getContext('2d');
        let imageData = tempCtx.getImageData(0, 0, currentWidth, currentHeight);
        const data = imageData.data;

        if (currentFilter === 'grayscale') {
            for (let i = 0; i < data.length; i += 4) {
                const gray = (data[i] + data[i + 1] + data[i + 2]) / 3;
                data[i] = gray;
                data[i + 1] = gray;
                data[i + 2] = gray;
            }
        } else if (currentFilter === 'sepia') {
            for (let i = 0; i < data.length; i += 4) {
                const r = data[i], g = data[i + 1], b = data[i + 2];
                data[i] = Math.min(255, (r * 0.393) + (g * 0.769) + (b * 0.189));
                data[i + 1] = Math.min(255, (r * 0.349) + (g * 0.686) + (b * 0.168));
                data[i + 2] = Math.min(255, (r * 0.272) + (g * 0.534) + (b * 0.131));
            }
        } else if (currentFilter === 'brightness') {
            for (let i = 0; i < data.length; i += 4) {
                data[i] = Math.min(255, data[i] + 50);
                data[i + 1] = Math.min(255, data[i + 1] + 50);
                data[i + 2] = Math.min(255, data[i + 2] + 50);
            }
        } else if (currentFilter === 'blur') {
            const width = currentWidth, height = currentHeight;
            const tempData = new Uint8ClampedArray(data);
            for (let y = 1; y < height - 1; y++) {
                for (let x = 1; x < width - 1; x++) {
                    const idx = (y * width + x) * 4;
                    let r = 0, g = 0, b = 0;
                    for (let ky = -1; ky <= 1; ky++) {
                        for (let kx = -1; kx <= 1; kx++) {
                            const nidx = ((y + ky) * width + (x + kx)) * 4;
                            r += tempData[nidx];
                            g += tempData[nidx + 1];
                            b += tempData[nidx + 2];
                        }
                    }
                    data[idx] = r / 9;
                    data[idx + 1] = g / 9;
                    data[idx + 2] = b / 9;
                }
            }
        }
        tempCtx.putImageData(imageData, 0, 0);
    }

    previewCanvas.width = currentWidth;
    previewCanvas.height = currentHeight;
    previewCtx.drawImage(resizedCanvas, 0, 0);
    document.getElementById('sizeInfo').innerHTML = `<span>📐 Image resized to ${currentWidth} × ${currentHeight} pixels</span>`;
}

function applyResize() {
    currentWidth = parseInt(document.getElementById('targetWidth').value) || 150;
    currentHeight = parseInt(document.getElementById('targetHeight').value) || 150;
    if (currentWidth < 10) currentWidth = 10;
    if (currentHeight < 10) currentHeight = 10;
    if (currentWidth > 1000) currentWidth = 1000;
    if (currentHeight > 1000) currentHeight = 1000;
    document.getElementById('targetWidth').value = currentWidth;
    document.getElementById('targetHeight').value = currentHeight;
    updatePreview();
}

function applyFilter(filter) {
    if (!originalImage) return;
    if (filter === 'reset') {
        currentFilter = 'original';
        updatePreview();
        return;
    }
    currentFilter = filter;
    updatePreview();
}

function setupImageUpload() {
    const uploadArea = document.getElementById('uploadArea');
    const imageUpload = document.getElementById('imageUpload');

    if (uploadArea && imageUpload) {
        uploadArea.onclick = () => imageUpload.click();
        imageUpload.onchange = (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (event) {
                    const img = new Image();
                    img.onload = function () {
                        originalImage = img;
                        originalCanvas.width = img.width;
                        originalCanvas.height = img.height;
                        originalCtx.drawImage(img, 0, 0);
                        currentFilter = 'original';
                        updatePreview();
                    };
                    img.src = event.target.result;
                };
                reader.readAsDataURL(file);
            }
        };
    }
}

function saveProfilePicture() {
    if (!originalImage) {
        alert("Please upload an image first!");
        return;
    }

    const finalImage = resizeImageToFit(originalImage, currentWidth, currentHeight);

    if (currentFilter !== 'original' && currentFilter !== 'reset') {
        const finalCtx = finalImage.getContext('2d');
        let imageData = finalCtx.getImageData(0, 0, currentWidth, currentHeight);
        const data = imageData.data;

        if (currentFilter === 'grayscale') {
            for (let i = 0; i < data.length; i += 4) {
                const gray = (data[i] + data[i + 1] + data[i + 2]) / 3;
                data[i] = gray;
                data[i + 1] = gray;
                data[i + 2] = gray;
            }
        } else if (currentFilter === 'sepia') {
            for (let i = 0; i < data.length; i += 4) {
                const r = data[i], g = data[i + 1], b = data[i + 2];
                data[i] = Math.min(255, (r * 0.393) + (g * 0.769) + (b * 0.189));
                data[i + 1] = Math.min(255, (r * 0.349) + (g * 0.686) + (b * 0.168));
                data[i + 2] = Math.min(255, (r * 0.272) + (g * 0.534) + (b * 0.131));
            }
        } else if (currentFilter === 'brightness') {
            for (let i = 0; i < data.length; i += 4) {
                data[i] = Math.min(255, data[i] + 50);
                data[i + 1] = Math.min(255, data[i + 1] + 50);
                data[i + 2] = Math.min(255, data[i + 2] + 50);
            }
        } else if (currentFilter === 'blur') {
            const width = currentWidth, height = currentHeight;
            const tempData = new Uint8ClampedArray(data);
            for (let y = 1; y < height - 1; y++) {
                for (let x = 1; x < width - 1; x++) {
                    const idx = (y * width + x) * 4;
                    let r = 0, g = 0, b = 0;
                    for (let ky = -1; ky <= 1; ky++) {
                        for (let kx = -1; kx <= 1; kx++) {
                            const nidx = ((y + ky) * width + (x + kx)) * 4;
                            r += tempData[nidx];
                            g += tempData[nidx + 1];
                            b += tempData[nidx + 2];
                        }
                    }
                    data[idx] = r / 9;
                    data[idx + 1] = g / 9;
                    data[idx + 2] = b / 9;
                }
            }
        }
        finalCtx.putImageData(imageData, 0, 0);
    }

    const savedImage = finalImage.toDataURL();
    localStorage.setItem(`profile_${userData.email}`, savedImage);

    const profileResized = resizeImageToFit(originalImage, 150, 150);
    let profileFinalCtx = profileResized.getContext('2d');

    profileCanvas.width = 150;
    profileCanvas.height = 150;
    profileCtx.drawImage(profileResized, 0, 0);

    alert("✅ Profile picture saved successfully!");
    location.reload();
}

function setupFilterButtons() {
    const buttons = {
        'grayscale': () => applyFilter('grayscale'),
        'sepia': () => applyFilter('sepia'),
        'brightness': () => applyFilter('brightness'),
        'blur': () => applyFilter('blur'),
        'reset': () => applyFilter('reset')
    };

    for (const [id, handler] of Object.entries(buttons)) {
        const btn = document.getElementById(id);
        if (btn) btn.onclick = handler;
    }

    const applyResizeBtn = document.getElementById('applyResizeBtn');
    if (applyResizeBtn) applyResizeBtn.onclick = applyResize;
}

function resetToSaved() {
    const savedImage = localStorage.getItem(`profile_${userData.email}`);
    if (savedImage) {
        const img = new Image();
        img.onload = function () {
            originalImage = img;
            originalCanvas.width = img.width;
            originalCanvas.height = img.height;
            originalCtx.drawImage(img, 0, 0);
            currentFilter = 'original';
            updatePreview();
            alert("✅ Reset to saved profile picture");
        };
        img.src = savedImage;
    } else {
        alert("No saved profile picture found. Upload one first!");
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadSavedProfilePicture();
    setupImageUpload();
    setupFilterButtons();

    const saveBtn = document.getElementById('saveBtn');
    if (saveBtn) saveBtn.onclick = saveProfilePicture;

    const resetBtn = document.getElementById('resetToSavedBtn');
    if (resetBtn) resetBtn.onclick = resetToSaved;

    document.getElementById('targetWidth').value = 150;
    document.getElementById('targetHeight').value = 150;
});