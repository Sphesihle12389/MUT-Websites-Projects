// login.js - Login Page Functions

let isSignupMode = false;

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@([^\s@]+\.)+[^\s@]+$/;
    return emailRegex.test(email);
}

function showMessage(msg, type) {
    const box = document.getElementById("messageBox");
    if (!box) return;
    box.textContent = msg;
    box.className = `message-box ${type === 'error' ? 'error-msg' : 'success-msg'}`;
    box.style.display = "block";
    setTimeout(() => box.style.display = "none", 4000);
}

function continueAsGuest() {
    sessionStorage.setItem("mut_auth_user", JSON.stringify({
        email: "guest@mut.ac.za",
        name: "Guest User",
        phone: "",
        isGuest: true
    }));
    window.location.href = "welcome.html";
}

let timerInterval = null;
let canResend = false;
let currentEmail = '';

function startResendTimer() {
    let timeLeft = 30;
    canResend = false;
    const timerDiv = document.getElementById("resendTimer");

    if (timerInterval) clearInterval(timerInterval);

    timerInterval = setInterval(() => {
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            canResend = true;
            timerDiv.innerHTML = '<span style="color:#C9962A;">📧 Resend OTP</span>';
            timerDiv.style.cursor = "pointer";
        } else {
            timerDiv.innerHTML = `⏳ Resend OTP in ${timeLeft} seconds`;
            timerDiv.style.cursor = "not-allowed";
        }
        timeLeft--;
    }, 1000);
}

function setupSendOTP() {
    const sendOtpBtn = document.getElementById("sendOtpBtn");
    if (sendOtpBtn) {
        sendOtpBtn.onclick = async () => {
            const email = document.getElementById("signupEmail").value.trim();

            if (!email) {
                showMessage("❌ Please enter your email address", "error");
                return;
            }

            if (!isValidEmail(email)) {
                showMessage("❌ Please enter a valid email address", "error");
                return;
            }

            currentEmail = email;
            const btn = document.getElementById("sendOtpBtn");
            btn.textContent = "⏳ Sending OTP...";
            btn.disabled = true;

            try {
                const response = await fetch('/api/send-otp', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email })
                });
                const data = await response.json();
                if (data.success) {
                    showMessage(`📧 OTP sent to ${email}! Check your inbox.`, "info");
                    document.getElementById("otpSection").style.display = "block";
                    startResendTimer();
                } else {
                    showMessage("❌ " + data.message, "error");
                    btn.disabled = false;
                    btn.textContent = "📧 Send OTP Code";
                }
            } catch (err) {
                showMessage("❌ Server error. Please try again.", "error");
                btn.disabled = false;
                btn.textContent = "📧 Send OTP Code";
            }
            btn.disabled = false;
            btn.textContent = "📧 Send OTP Code";
        };
    }
}

function setupResendOTP() {
    const resendTimer = document.getElementById("resendTimer");
    if (resendTimer) {
        resendTimer.onclick = async () => {
            if (!canResend) return;

            if (!currentEmail) {
                showMessage("❌ Please enter your email first", "error");
                return;
            }

            const btn = document.getElementById("sendOtpBtn");
            btn.textContent = "⏳ Resending...";
            btn.disabled = true;

            try {
                const response = await fetch('/api/send-otp', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: currentEmail })
                });
                const data = await response.json();
                if (data.success) {
                    showMessage(`📧 New OTP sent to ${currentEmail}!`, "success");
                    startResendTimer();
                } else {
                    showMessage("❌ " + data.message, "error");
                }
            } catch (err) {
                showMessage("❌ Server error", "error");
            }
            btn.textContent = "📧 Send OTP Code";
            btn.disabled = false;
        };
    }
}

function setupVerifyOTP() {
    const verifyOtpBtn = document.getElementById("verifyOtpBtn");
    if (verifyOtpBtn) {
        verifyOtpBtn.onclick = async () => {
            const email = document.getElementById("signupEmail").value.trim();
            const otp = document.getElementById("otpCode").value.trim();

            if (!email || !otp) {
                showMessage("❌ Please enter email and OTP", "error");
                return;
            }

            if (otp.length !== 6) {
                showMessage("❌ Please enter the 6-digit OTP code", "error");
                return;
            }

            const btn = document.getElementById("verifyOtpBtn");
            btn.textContent = "⏳ Verifying...";
            btn.disabled = true;

            try {
                const response = await fetch('/api/verify-otp', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, otp })
                });
                const data = await response.json();
                if (data.success) {
                    showMessage("✅ Email verified successfully!", "success");
                    document.getElementById("continueBtn").disabled = false;
                    document.getElementById("continueBtn").style.opacity = "1";
                } else {
                    showMessage("❌ " + data.message, "error");
                }
            } catch (err) {
                showMessage("❌ Server error", "error");
            }
            btn.textContent = "✓ Verify OTP";
            btn.disabled = false;
        };
    }
}

function setupCompleteRegistration() {
    const completeBtn = document.getElementById("completeSignupBtn");
    if (completeBtn) {
        completeBtn.onclick = async () => {
            const email = document.getElementById("signupEmail").value.trim();
            const phone = document.getElementById("signupPhone").value.trim();
            const name = document.getElementById("signupName").value.trim();
            const password = document.getElementById("signupPassword").value.trim();
            const confirmPassword = document.getElementById("confirmPassword").value.trim();

            if (!password || !confirmPassword) {
                showMessage("❌ Please create a password", "error");
                return;
            }

            if (password.length < 6) {
                showMessage("❌ Password must be at least 6 characters", "error");
                return;
            }

            if (password !== confirmPassword) {
                showMessage("❌ Passwords do not match", "error");
                return;
            }

            try {
                const response = await fetch('/api/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password, phone, name })
                });
                const data = await response.json();
                if (data.success) {
                    showMessage("✅ Account created! Redirecting to login...", "success");
                    setTimeout(() => {
                        window.location.href = "login.html";
                    }, 1500);
                } else {
                    showMessage("❌ " + data.message, "error");
                }
            } catch (err) {
                showMessage("❌ Server error", "error");
            }
        };
    }
}

function setupLoginForm() {
    const loginBtn = document.getElementById("loginBtn");
    if (loginBtn) {
        loginBtn.onclick = async () => {
            const email = document.getElementById("loginEmail").value.trim();
            const password = document.getElementById("loginPassword").value.trim();

            if (!email || !password) {
                showMessage("❌ Fill all fields", "error");
                return;
            }

            if (!isValidEmail(email)) {
                showMessage("❌ Invalid email format!", "error");
                return;
            }

            try {
                const response = await fetch('/api/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });
                const data = await response.json();
                if (data.success) {
                    showMessage("✅ Login successful! Redirecting...", "success");
                    sessionStorage.setItem("mut_auth_user", JSON.stringify(data.user));
                    setTimeout(() => {
                        window.location.href = "welcome.html";
                    }, 800);
                } else {
                    showMessage("❌ " + data.message, "error");
                }
            } catch (err) {
                showMessage("❌ Server error", "error");
            }
        };
    }
}

function toggleSignupMode() {
    const switchBtn = document.getElementById("switchBtn");
    if (switchBtn) {
        switchBtn.onclick = () => {
            isSignupMode = !isSignupMode;
            const loginForm = document.getElementById("loginForm");
            const signupForm = document.getElementById("signupForm");
            const header = document.getElementById("formHeader");
            const switchText = document.getElementById("switchText");
            const switchBtnElem = document.getElementById("switchBtn");

            if (isSignupMode) {
                if (loginForm) loginForm.style.display = "none";
                if (signupForm) signupForm.style.display = "block";
                if (header) header.innerHTML = "<h2>Create Your Account</h2><p>Verify your email to join MUT ICT</p>";
                if (switchText) switchText.innerHTML = "Already have an account? ";
                if (switchBtnElem) switchBtnElem.innerHTML = "Sign in";
            } else {
                if (loginForm) loginForm.style.display = "block";
                if (signupForm) signupForm.style.display = "none";
                if (header) header.innerHTML = "<h2>Welcome back</h2><p>Sign in to access your student portal</p>";
                if (switchText) switchText.innerHTML = "New to MUT ICT? ";
                if (switchBtnElem) switchBtnElem.innerHTML = "Create an account";
            }
        };
    }
}

document.addEventListener('DOMContentLoaded', () => {
    setupLoginForm();
    setupSendOTP();
    setupResendOTP();
    setupVerifyOTP();
    setupCompleteRegistration();
    toggleSignupMode();

    const guestBtn = document.getElementById("guestBtn");
    if (guestBtn) guestBtn.onclick = continueAsGuest;

    const guestBtnSignup = document.getElementById("guestBtnSignup");
    if (guestBtnSignup) guestBtnSignup.onclick = continueAsGuest;
});