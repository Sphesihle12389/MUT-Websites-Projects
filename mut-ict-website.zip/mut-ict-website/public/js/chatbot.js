// chatbot.js - Chatbot Functions for All Pages

function setupChatbot() {
    const chatToggle = document.getElementById("chatToggle");
    const chatWindow = document.getElementById("chatWindow");
    const closeChat = document.getElementById("closeChat");

    if (chatToggle) {
        chatToggle.onclick = () => {
            chatWindow.style.display = chatWindow.style.display === "flex" ? "none" : "flex";
        };
    }

    if (closeChat) {
        closeChat.onclick = () => {
            chatWindow.style.display = "none";
        };
    }
}

function escapeHtml(text) {
    return text.replace(/[&<>]/g, function (m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

async function sendChatMessage() {
    const input = document.getElementById("chatInput");
    const msg = input.value.trim();
    if (!msg) return;

    const messagesDiv = document.getElementById("chatMessages");
    messagesDiv.innerHTML += `<div class="message user-msg">${escapeHtml(msg)}</div>`;
    input.value = "";

    messagesDiv.innerHTML += `<div class="message bot-msg typing">MUTi is thinking<span>.</span><span>.</span><span>.</span></div>`;
    messagesDiv.scrollTop = messagesDiv.scrollHeight;

    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: msg })
        });
        const data = await response.json();

        const typingMsg = document.querySelector('.typing');
        if (typingMsg) typingMsg.remove();

        let formattedReply = data.reply.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        formattedReply = formattedReply.replace(/\n/g, '<br>');

        messagesDiv.innerHTML += `<div class="message bot-msg">${formattedReply}</div>`;
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
    } catch (err) {
        const typingMsg = document.querySelector('.typing');
        if (typingMsg) typingMsg.remove();
        messagesDiv.innerHTML += `<div class="message bot-msg">Sorry, I'm having trouble connecting. Please try again later or contact support at 031-907-7111.</div>`;
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }
}

function setupMicrophone() {
    const micBtn = document.getElementById("micBtn");
    if (micBtn && 'webkitSpeechRecognition' in window) {
        const recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.lang = "en-US";
        micBtn.onclick = () => recognition.start();
        recognition.onresult = (e) => {
            document.getElementById("chatInput").value = e.results[0][0].transcript;
        };
        recognition.onerror = () => {
            micBtn.style.backgroundColor = "#C9962A";
        };
        recognition.onend = () => {
            micBtn.style.backgroundColor = "#C9962A";
        };
    } else if (micBtn) {
        micBtn.style.display = "none";
    }
}

function setupWhatsApp() {
    const whatsappBtn = document.getElementById("whatsappBtn");
    if (whatsappBtn) {
        whatsappBtn.onclick = () => {
            const msg = document.getElementById("chatInput").value.trim();
            window.open(`https://wa.me/27738855903?text=${encodeURIComponent(msg || "Hello MUT ICT")}`, "_blank");
        };
    }
}

document.addEventListener('DOMContentLoaded', () => {
    setupChatbot();
    setupMicrophone();
    setupWhatsApp();
});