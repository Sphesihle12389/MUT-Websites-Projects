// welcome.js - Welcome Page Functions

let isLoggedIn = false;
let userData = null;

function checkWelcomeAuth() {
    const user = sessionStorage.getItem("mut_auth_user");
    if (!user) {
        window.location.href = "login.html";
        return false;
    }

    userData = JSON.parse(user);
    isLoggedIn = !userData.isGuest;

    if (!isLoggedIn) {
        document.getElementById("userNameDisplay").innerHTML = "Guest User";
        const heroSection = document.querySelector('.hero-welcome');
        if (heroSection && !document.querySelector('.guest-banner')) {
            const guestBanner = document.createElement('div');
            guestBanner.className = 'guest-banner';
            guestBanner.innerHTML = '👋 You are browsing as a guest. <a href="login.html">Login</a> or <a href="login.html#signup">Sign up</a> for full access.';
            heroSection.parentNode.insertBefore(guestBanner, heroSection);
        }
    } else {
        document.getElementById("userNameDisplay").innerHTML = userData.name || userData.email.split('@')[0];
    }
    return true;
}

function setupCards() {
    const cards = document.querySelectorAll(".nav-card");
    const pageUrls = [
        "index.html", "why.html", "course.html", "careers.html",
        "admission.html", "profile.html", "id-card.html"
    ];
    const pageTitles = [
        "🏠 Home", "💡 Why ICT?", "📚 Qualifications", "💼 Careers",
        "📝 Admission", "👤 My Profile", "🪪 ID Card"
    ];
    const popupTexts = [
        "Welcome to the MUT ICT Portal. Stay updated with department news.",
        "ICT is one of the fastest-growing industries. Every company needs ICT specialists.",
        "MUT offers Diploma in IT (3 years), ECP (4 years) and Advanced Diploma (1 year).",
        "ICT graduates can become Software Developers, Network Engineers, Cybersecurity Specialists.",
        "Applicants need English, Mathematics, and enough APS points.",
        "Upload and manage your profile picture. Apply filters and save to your account.",
        "Generate your official MUT Student ID Card with photo."
    ];

    for (let i = 0; i < cards.length && i < pageUrls.length; i++) {
        const card = cards[i];
        const url = pageUrls[i];
        const title = pageTitles[i];
        const popupText = popupTexts[i];

        card.onclick = () => {
            if (isLoggedIn) {
                window.location.href = url;
            } else {
                showPopup(title, popupText);
            }
        };
    }

    // Blackboard card
    const blackboardCard = document.querySelector('.blackboard-card');
    if (blackboardCard) {
        blackboardCard.onclick = () => {
            if (isLoggedIn) {
                window.open("https://mutelearn.mut.ac.za/", "_blank");
            } else {
                showPopup("💻 Blackboard", "Please login to access the MUT e-learning platform.");
            }
        };
    }
}

function setupPopupModal() {
    const modalDiv = document.createElement("div");
    modalDiv.innerHTML = `
        <div id="popupModal" class="popup-modal">
            <div class="popup-content">
                <span class="close-btn">&times;</span>
                <h2 id="popupTitle"></h2>
                <p id="popupText"></p>
                <button class="popup-login-btn" onclick="window.location.href='login.html'">Login / Sign Up</button>
            </div>
        </div>
    `;
    document.body.appendChild(modalDiv);

    document.addEventListener("click", function (e) {
        if (e.target.classList.contains("close-btn") || e.target.id === "popupModal") {
            document.getElementById("popupModal").style.display = "none";
        }
    });
}

function showPopup(title, text) {
    const popupTitle = document.getElementById("popupTitle");
    const popupText = document.getElementById("popupText");
    if (popupTitle) popupTitle.innerText = title;
    if (popupText) popupText.innerText = text;
    const modal = document.getElementById("popupModal");
    if (modal) modal.style.display = "block";
}

function setupCalendarModal() {
    const modal = document.getElementById("calendarModal");
    if (!modal) return;

    window.openCalendarModal = function () {
        if (!isLoggedIn) {
            showPopup("📅 Academic Calendar", "Please login to view the full MUT Academic Calendar.");
            return;
        }
        modal.style.display = "block";
        document.body.style.overflow = "hidden";
    };

    window.closeCalendarModal = function () {
        modal.style.display = "none";
        document.body.style.overflow = "auto";
    };

    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
            document.body.style.overflow = "auto";
        }
    };
}

document.addEventListener('DOMContentLoaded', () => {
    if (checkWelcomeAuth()) {
        setupCards();
        setupPopupModal();
        setupCalendarModal();
    }
});