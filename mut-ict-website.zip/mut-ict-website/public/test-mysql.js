// test-db.js
require('dotenv').config();
const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'mut_ict_db'
});

connection.connect((err) => {
    if (err) {
        console.error('❌ Connection failed:', err.message);
        console.log('\n💡 Check your .env file password!');
        return;
    }
    console.log('✅ MySQL Connected Successfully!');
    
    connection.query('SELECT * FROM users', (err, results) => {
        if (err) throw err;
        console.log('Users in database:', results);
        connection.end();
    });
});