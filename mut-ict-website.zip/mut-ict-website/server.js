const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const mysql = require('mysql2');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// ================= MYSQL DATABASE CONNECTION =================
const db = mysql.createConnection({
    host: '127.0.0.1',
    user: 'root',
    password: '@SpheH2blevel4',
    database: 'mutict'
});

// Connect to MySQL
db.connect((err) => {
    if (err) {
        console.log('❌ MySQL Connection Failed:', err);
        return;
    }
    console.log('✅ MySQL Connected Successfully');
    
    // Create tables if they don't exist
    createTables();
});

// Function to create tables
function createTables() {
    // Users table
    db.query(`
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            phone VARCHAR(50),
            name VARCHAR(100),
            is_guest BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `, (err) => {
        if (err) console.error('Users table error:', err);
        else console.log('✅ Users table ready');
    });
    
    // OTPs table
    db.query(`
        CREATE TABLE IF NOT EXISTS otps (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) NOT NULL,
            otp_code VARCHAR(10) NOT NULL,
            expires_at DATETIME NOT NULL,
            attempts INT DEFAULT 0,
            is_used BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `, (err) => {
        if (err) console.error('OTPs table error:', err);
        else console.log('✅ OTPs table ready');
    });
    
    // Check if demo user exists
    db.query('SELECT * FROM users WHERE email = ?', ['student@mut.ac.za'], async (err, results) => {
        if (err) return;
        if (results.length === 0) {
            const hashedPassword = await bcrypt.hash('mut2026', 10);
            db.query(
                'INSERT INTO users (email, password, name, phone) VALUES (?, ?, ?, ?)',
                ['student@mut.ac.za', hashedPassword, 'Thabo', '+27781234567']
            );
            console.log('✅ Demo user created: student@mut.ac.za / mut2026');
        }
    });
}

// Promise wrapper for db queries
const queryAsync = (sql, params) => {
    return new Promise((resolve, reject) => {
        db.query(sql, params, (err, results) => {
            if (err) reject(err);
            else resolve(results);
        });
    });
};

// ================= EMAIL SETUP FOR OTP =================
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER || 'your_email@gmail.com',
        pass: process.env.EMAIL_PASS || 'your_app_password'
    }
});

// Generate random 6-digit OTP
function generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// Send OTP email
async function sendOTPEmail(email, otp) {
    const mailOptions = {
        from: `"MUT ICT Department" <${process.env.EMAIL_USER || 'your_email@gmail.com'}>`,
        to: email,
        subject: 'MUT ICT - Email Verification OTP',
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #f5f5f5;">
                <div style="background: linear-gradient(135deg, #6B1C20 0%, #8f2a2f 100%); padding: 20px; text-align: center; border-radius: 15px 15px 0 0;">
                    <h1 style="color: white; margin: 0;">MUT ICT Department</h1>
                </div>
                <div style="background: white; padding: 30px; border-radius: 0 0 15px 15px;">
                    <h2 style="color: #6B1C20;">Email Verification</h2>
                    <p>Hello,</p>
                    <p>Thank you for registering with the MUT ICT Department Portal. Please use the following One-Time Password (OTP) to verify your email address:</p>
                    <div style="text-align: center; margin: 30px 0;">
                        <div style="font-size: 36px; font-weight: bold; letter-spacing: 5px; background: #f0f0f0; padding: 15px; border-radius: 10px; font-family: monospace;">${otp}</div>
                    </div>
                    <p>This OTP is valid for <strong>5 minutes</strong>.</p>
                    <p>If you did not request this, please ignore this email.</p>
                    <hr style="margin: 20px 0;">
                    <p style="font-size: 12px; color: #888;">Mangosuthu University of Technology - Department of Information & Communication Technology</p>
                    <p style="margin-top: 15px;">📞 Contact: 031-907-7111 | 📧 ict@mut.ac.za</p>
                </div>
            </div>
        `,
        text: `MUT ICT Portal - Email Verification OTP: ${otp}\n\nThis OTP is valid for 5 minutes.\n\nIf you did not request this, please ignore this email.`
    };
    
    try {
        await transporter.sendMail(mailOptions);
        console.log(`✅ OTP email sent to: ${email}`);
        return true;
    } catch (error) {
        console.error('❌ Email send error:', error);
        return false;
    }
}

// ================= API ROUTES =================

// ========== 1. SEND OTP ==========
app.post('/api/send-otp', async (req, res) => {
    try {
        const { email } = req.body;
        
        if (!email) {
            return res.json({ success: false, message: "Email is required" });
        }
        
        // Check if email already registered
        const existingUsers = await queryAsync('SELECT * FROM users WHERE email = ?', [email]);
        
        if (existingUsers.length > 0) {
            return res.json({ success: false, message: "Email already registered. Please login." });
        }
        
        const otp = generateOTP();
        const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
        
        // Delete old OTPs for this email
        await queryAsync('DELETE FROM otps WHERE email = ? AND is_used = FALSE', [email]);
        
        // Save new OTP to database
        await queryAsync(
            'INSERT INTO otps (email, otp_code, expires_at) VALUES (?, ?, ?)',
            [email, otp, expiresAt]
        );
        
        // Send email
        const emailSent = await sendOTPEmail(email, otp);
        
        if (emailSent) {
            res.json({ success: true, message: `OTP sent to ${email}. Please check your inbox.` });
        } else {
            res.json({ success: false, message: "Failed to send email. Please check your email address or try again later." });
        }
    } catch (err) {
        console.error("Send OTP error:", err);
        res.status(500).json({ success: false, message: "Server error. Please try again." });
    }
});

// ========== 2. VERIFY OTP ==========
app.post('/api/verify-otp', async (req, res) => {
    try {
        const { email, otp } = req.body;
        
        if (!email || !otp) {
            return res.json({ success: false, message: "Email and OTP are required" });
        }
        
        // Get the latest OTP for this email
        const otpRecords = await queryAsync(
            'SELECT * FROM otps WHERE email = ? AND is_used = FALSE ORDER BY id DESC LIMIT 1',
            [email]
        );
        
        if (otpRecords.length === 0) {
            return res.json({ success: false, message: "No valid OTP found. Please request a new one." });
        }
        
        const otpRecord = otpRecords[0];
        
        // Check if OTP expired
        if (new Date() > new Date(otpRecord.expires_at)) {
            return res.json({ success: false, message: "OTP has expired. Please request a new one." });
        }
        
        // Check attempts
        if (otpRecord.attempts >= 3) {
            return res.json({ success: false, message: "Too many failed attempts. Please request a new OTP." });
        }
        
        // Verify OTP
        if (otpRecord.otp_code !== otp) {
            // Increment attempts
            await queryAsync('UPDATE otps SET attempts = attempts + 1 WHERE id = ?', [otpRecord.id]);
            return res.json({ success: false, message: "Invalid OTP. Please try again." });
        }
        
        // Mark OTP as used
        await queryAsync('UPDATE otps SET is_used = TRUE WHERE id = ?', [otpRecord.id]);
        
        res.json({ success: true, message: "OTP verified successfully! You can now complete your registration." });
    } catch (err) {
        console.error("Verify OTP error:", err);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// ========== 3. REGISTER (Complete Registration) ==========
app.post('/api/register', async (req, res) => {
    try {
        const { email, password, phone, name } = req.body;
        
        if (!email || !password) {
            return res.json({ success: false, message: "Email and password are required" });
        }
        
        if (password.length < 6) {
            return res.json({ success: false, message: "Password must be at least 6 characters" });
        }
        
        // Check if user already exists
        const existingUsers = await queryAsync('SELECT * FROM users WHERE email = ?', [email]);
        
        if (existingUsers.length > 0) {
            return res.json({ success: false, message: "Email already registered. Please login." });
        }
        
        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Insert new user
        await queryAsync(
            'INSERT INTO users (email, password, name, phone) VALUES (?, ?, ?, ?)',
            [email, hashedPassword, name || email.split('@')[0], phone || '']
        );
        
        console.log(`✅ New user registered: ${email}`);
        
        res.json({
            success: true,
            message: "Account created successfully!",
            user: {
                email: email,
                name: name || email.split('@')[0],
                phone: phone || ''
            }
        });
    } catch (err) {
        console.error("Registration error:", err);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// ========== 4. LOGIN ==========
app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        if (!email || !password) {
            return res.json({ success: false, message: "Email and password required" });
        }
        
        const users = await queryAsync('SELECT * FROM users WHERE email = ?', [email]);
        
        if (users.length === 0) {
            return res.json({ success: false, message: "Invalid email or password" });
        }
        
        const user = users[0];
        const passwordMatch = await bcrypt.compare(password, user.password);
        
        if (!passwordMatch) {
            return res.json({ success: false, message: "Invalid email or password" });
        }
        
        res.json({
            success: true,
            user: {
                email: user.email,
                name: user.name,
                phone: user.phone
            }
        });
    } catch (err) {
        console.error("Login error:", err);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// ========== 5. LOGOUT ==========
app.post('/api/logout', (req, res) => {
    res.json({ success: true });
});

// ========== 6. GET ALL USERS (Admin) ==========
app.get('/api/users', async (req, res) => {
    try {
        const users = await queryAsync('SELECT id, email, name, phone, created_at FROM users', []);
        res.json({ success: true, users });
    } catch (err) {
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// ========== 7. GET USER PROFILE ==========
app.get('/api/profile/:email', async (req, res) => {
    try {
        const { email } = req.params;
        const users = await queryAsync('SELECT id, email, name, phone, created_at FROM users WHERE email = ?', [email]);
        
        if (users.length === 0) {
            return res.json({ success: false, message: "User not found" });
        }
        
        res.json({ success: true, user: users[0] });
    } catch (err) {
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// ========== 8. UPDATE USER PROFILE ==========
app.put('/api/profile/:email', async (req, res) => {
    try {
        const { email } = req.params;
        const { name, phone } = req.body;
        
        await queryAsync(
            'UPDATE users SET name = ?, phone = ? WHERE email = ?',
            [name, phone, email]
        );
        
        res.json({ success: true, message: "Profile updated successfully" });
    } catch (err) {
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// ========== 9. COMPLETE SMART CHATBOT ==========
app.post('/api/chat', (req, res) => {
    const userMessage = req.body.message.toLowerCase().trim();
    
    // Helper function for fuzzy matching (handles spelling mistakes)
    function fuzzyMatch(text, keywords) {
        for (let keyword of keywords) {
            if (text.includes(keyword)) return true;
            // Common spelling variations
            const variations = {
                'course': ['course', 'courses', 'cource', 'corses', 'coarse', 'cours'],
                'admission': ['admission', 'admissions', 'adimission', 'admisson', 'admistion'],
                'apply': ['apply', 'application', 'applying', 'aply', 'applicant'],
                'career': ['career', 'careers', 'carer', 'carreer', 'job', 'jobs', 'work'],
                'contact': ['contact', 'contacts', 'contac', 'kontact', 'phone', 'call', 'email'],
                'qualification': ['qualification', 'qualifications', 'qualif', 'certificate', 'programme'],
                'diploma': ['diploma', 'diplomas', 'diplomer', 'dip'],
                'exam': ['exam', 'exams', 'examination', 'test', 'assessment'],
                'graduation': ['graduation', 'graduate', 'grad', 'ceremony'],
                'registration': ['registration', 'register', 'enroll', 'enrolment'],
                'bursary': ['bursary', 'bursaries', 'funding', 'nsfas', 'financial'],
                'residence': ['residence', 'hostel', 'accommodation', 'living'],
                'library': ['library', 'libraries', 'books', 'study'],
                'sport': ['sport', 'sports', 'gym', 'recreation'],
                'history': ['history', 'overview', 'background', 'established', 'founded'],
                'vision': ['vision', 'mission', 'values', 'motto'],
                'faculty': ['faculty', 'faculties', 'school', 'department'],
                'ict': ['ict', 'information technology', 'computer', 'it department'],
                'profile': ['profile', 'picture', 'photo', 'avatar', 'upload'],
                'id card': ['id card', 'student card', 'identification', 'idcard'],
                'payment': ['payment', 'bank', 'banking', 'fees', 'fee']
            };
            
            if (variations[keyword] && variations[keyword].some(variant => text.includes(variant))) {
                return true;
            }
        }
        return false;
    }
    
    let reply = "";
    
    // WEBSITE PAGES INFORMATION
    if (fuzzyMatch(userMessage, ['home', 'index', 'main page', 'welcome'])) {
        reply = `🏠 **HOME PAGE - MUT ICT Department**\n\n📌 **What you'll find on Home page:**\n• Latest news about ICT Department\n• Announcements and updates\n• Quick statistics (Programmes: 5+, Students: 1200+, Partners: 45+, Employability: 92%)\n• Links to all sections\n• Events calendar`;
    }
    else if (fuzzyMatch(userMessage, ['why ict', 'benefits', 'why choose', 'advantage', 'why study'])) {
        reply = `💡 **WHY ICT AT MUT - Key Benefits**\n\n✅ **6 Reasons to Study ICT:**\n1️⃣ Every company needs an ICT specialist\n2️⃣ Manage hardware and software systems\n3️⃣ Streamline business processes\n4️⃣ Design, maintain data systems\n5️⃣ MUT qualification prepares you for workplace\n6️⃣ Global career opportunities (R25k-R100k+)\n\n📈 **Additional Benefits:** High global demand, Work-Integrated Learning, Modern labs, Industry partners: Microsoft, AWS, Vodacom`;
    }
    else if (fuzzyMatch(userMessage, ['qualification', 'course', 'programme', 'diploma', 'study', 'what can i study'])) {
        reply = `📚 **MUT ICT QUALIFICATIONS**\n\n🎓 **1. Diploma in Information Technology**\n• NQF Level: 6 | Credits: 360 | Duration: 3 Years\n\n📗 **2. Extended Curriculum Programme (ECP)**\n• NQF Level: 6 | Credits: 480 | Duration: 4 Years\n\n📕 **3. Advanced Diploma in ICT**\n• NQF Level: 7 | Credits: 120 | Duration: 1 Year\n\nAll qualifications are SAQA registered and DHET approved!`;
    }
    else if (fuzzyMatch(userMessage, ['career', 'job', 'work', 'salary', 'employment', 'how much', 'earn'])) {
        reply = `💼 **CAREER OPPORTUNITIES FOR ICT GRADUATES**\n\n💰 **Salaries:**\n• Software Developer: R35k - R85k/month\n• Network Engineer: R45k - R110k/month\n• Cybersecurity Analyst: R40k - R95k/month\n• Cloud Specialist: R60k - R130k/month\n• Database Administrator: R38k - R85k/month\n• Data Engineer: R42k - R100k/month\n\n🏢 **Top Employers:** Microsoft, AWS, Vodacom, MTN, Standard Bank, Discovery, Deloitte`;
    }
    else if (fuzzyMatch(userMessage, ['admission', 'apply', 'application', 'requirements', 'entry', 'how to apply'])) {
        reply = `📝 **ADMISSION REQUIREMENTS**\n\n🎓 **Diploma in IT:**\n• NSC with Bachelor/Diploma endorsement\n• Mathematics: 50% minimum\n• English: 40% (Home) or 50% (FAL)\n• APS score: 24+\n\n📚 **Extended Curriculum (ECP):**\n• Mathematics: 40% minimum\n• English: 40% minimum\n• Limited intake - APPLY EARLY!\n\n📌 Apply via CAO: www.cao.ac.za (CAO Code: MUT)`;
    }
    else if (fuzzyMatch(userMessage, ['id card', 'student card', 'generate card', 'identification', 'id'])) {
        reply = `🪪 **STUDENT ID CARD GENERATOR**\n\n📌 **How to generate your ID Card:**\n1️⃣ Go to "ID Card" page in the sidebar\n2️⃣ Upload your photo\n3️⃣ Enter your full name and student number\n4️⃣ Select your course and year level\n5️⃣ Click "Generate ID Card"\n\n✅ **Features:** Print, Download as PNG, Download Collection Letter\n\n🏢 After generating, visit MUT ICT Department to collect your physical ID card.`;
    }
    else if (fuzzyMatch(userMessage, ['profile', 'picture', 'upload photo', 'avatar', 'photo'])) {
        reply = `👤 **PROFILE PAGE - Manage Your Account**\n\n📸 **What you can do:**\n• Upload your profile picture\n• Apply filters (Grayscale, Sepia, Brightness, Contrast, Blur)\n• Auto-resize without cropping\n• Save picture to profile\n• Your picture appears on the sidebar logo on ALL pages!`;
    }
    else if (fuzzyMatch(userMessage, ['image process', 'filter', 'edit photo', 'effects', 'image'])) {
        reply = `🖼️ **IMAGE PROCESSING PAGE - Edit Your Photos**\n\n🎨 **Available Filters:**\n• ⚫ Grayscale - Black and white\n• 🟤 Sepia - Vintage effect\n• ✨ Brightness - Increase brightness\n• 🔆 Contrast - Increase contrast\n• 🌀 Blur - Soften the image\n\n📌 Upload an image, apply filters, and save to your profile!`;
    }
    else if (fuzzyMatch(userMessage, ['database', 'mysql', 'sql', 'crud', 'query', 'lesson'])) {
        reply = `🗄️ **DATABASE LESSON - MySQL with Express.js**\n\n📊 **What is a Database?** Organized collection of structured information.\n\n🔄 **CRUD Operations:**\n• CREATE: INSERT INTO table VALUES (...)\n• READ: SELECT * FROM table\n• UPDATE: UPDATE table SET column = value\n• DELETE: DELETE FROM table WHERE condition\n\n🔒 Always use parameterized queries to prevent SQL injection!`;
    }
    // GENERAL MUT INFORMATION
    else if (fuzzyMatch(userMessage, ['address', 'location', 'where', 'campus'])) {
        reply = `📍 **MUT ADDRESS**\n\n🏛️ **Physical Address:**\n511 Mangosuthu Highway, Umlazi, Durban, 4026\n\n📮 **Postal Address:**\nP.O Box 12363, Jacobs, Durban, 4026`;
    }
    else if (fuzzyMatch(userMessage, ['contact', 'phone', 'call', 'email', 'whatsapp', 'number'])) {
        reply = `📞 **MUT CONTACT DETAILS**\n\n📞 Switchboard: (031) 907-7111\n📧 ICT Department: ict@mut.ac.za\n👨‍💼 HOD Email: Vikash@mut.ac.za\n📱 WhatsApp: 063 885 5903\n🌐 Website: www.mut.ac.za`;
    }
    else if (fuzzyMatch(userMessage, ['exam', 'test', 'assessment', 'dates', 'when is exam'])) {
        reply = `📝 **2026 EXAMINATION DATES**\n\n📖 First Semester Exams: 19 May – 01 June 2026\n📖 Second Semester Exams: 04 November – 17 November 2026\n📖 Supplementary Exams: January 2027\n\nGood luck with your exams! 🍀`;
    }
    else if (fuzzyMatch(userMessage, ['graduation', 'graduate', 'ceremony', 'grad'])) {
        reply = `🎓 **2026 GRADUATION CEREMONIES**\n\n📅 Engineering: 21 April 2026\n📅 Management Sciences: 22 April 2026\n📅 Applied & Health Sciences: 23 April 2026\n\n📍 Venue: MUT Auditorium\n\n🎉 Congratulations to all graduates!`;
    }
    else if (fuzzyMatch(userMessage, ['register', 'registration', 'enroll', 'enrolment'])) {
        reply = `📝 **REGISTRATION INFORMATION**\n\n🗓️ New students: 19 January 2026\n🗓️ Returning students: 22 January 2026\n📚 Lectures commence: 02 February 2026\n💰 Registration Fee: R500`;
    }
    else if (fuzzyMatch(userMessage, ['bursary', 'funding', 'nsfas', 'financial', 'money'])) {
        reply = `💰 **BURSARY & FUNDING OPPORTUNITIES**\n\n🏦 NSFAS: www.nsfas.org.za (Closing: 31 Jan)\n🏅 MUT Merit Bursary for top students\n🏆 External: Microsoft, MTN, Vodacom, Telkom\n\n📞 Financial Aid: (031) 907-7111`;
    }
    else if (fuzzyMatch(userMessage, ['history', 'established', 'background', 'founded', 'when'])) {
        reply = `📚 **MUT HISTORY**\n\n📅 1974: Idea began\n📅 1979: Teaching started\n📅 2007: Became University of Technology\n\n🏛️ Today: Leading university of technology in KZN`;
    }
    else if (fuzzyMatch(userMessage, ['vision', 'mission', 'values', 'motto', 'goals'])) {
        reply = `🎯 **MUT VISION & MISSION**\n\n🎯 **Vision:** To be an academically excellent University of Technology anchored in its communities.\n\n🚀 **Mission:** To offer technological programmes focusing on innovative problem-solving.\n\n⭐ **Values:** Accountability, Integrity, Respect, Excellence`;
    }
    else if (fuzzyMatch(userMessage, ['faculty', 'faculties', 'school', 'department'])) {
        reply = `🏫 **MUT FACULTIES**\n\n1️⃣ Faculty of Engineering\n2️⃣ Faculty of Management Sciences\n3️⃣ Faculty of Applied & Health Sciences`;
    }
    else if (fuzzyMatch(userMessage, ['wifi', 'internet', 'wireless', 'network'])) {
        reply = `🌐 **MUT Wi-Fi INFORMATION**\n\n• Free Wi-Fi on campus\n• Network: MUT-Student\n• Login: Student number\n• Password: Student portal password`;
    }
    else if (fuzzyMatch(userMessage, ['residence', 'hostel', 'accommodation', 'living'])) {
        reply = `🏠 **RESIDENCE & ACCOMMODATION**\n\n• On-campus accommodation available\n• Apply early - limited spaces!\n• Fees: R25,000 - R35,000 per year\n\n📞 Residence Office: (031) 907-7111`;
    }
    else if (fuzzyMatch(userMessage, ['library', 'books', 'study', 'libary'])) {
        reply = `📚 **MUT LIBRARY INFORMATION**\n\n🕒 Hours: Mon-Fri 8am-9pm, Sat 9am-4pm\n\n📚 Services: Books, e-books, journals, study areas, computer lab, printing\n\n🌐 Online: library.mut.ac.za`;
    }
    else if (fuzzyMatch(userMessage, ['sport', 'gym', 'recreation', 'athletic'])) {
        reply = `⚽ **MUT SPORTS & RECREATION**\n\n🏀 Sports: Soccer, Basketball, Netball, Athletics, Volleyball, Tennis, Cricket\n\n🏆 Annual Sports Day: September 2026`;
    }
    else if (fuzzyMatch(userMessage, ['bank', 'payment', 'fee', 'pay', 'cost'])) {
        reply = `🏦 **MUT BANKING DETAILS**\n\nBank: ABSA\nAccount: 4063827633\nBranch Code: 632005\n\n📌 Reference: Student number + Name`;
    }
    else if (fuzzyMatch(userMessage, ['student support', 'help', 'counseling', 'assistance'])) {
        reply = `🎓 **STUDENT SUPPORT SERVICES**\n\n📚 Academic advising & tutoring\n💼 Career counseling\n💊 Mental health support\n💰 Financial aid assistance\n👥 Peer mentorship\n\n📍 Student Support Centre | 📞 (031) 907-7111`;
    }
    else if (fuzzyMatch(userMessage, ['who are you', 'your name', 'what can you do', 'chatbot', 'mut i'])) {
        reply = `🤖 **I'm MUTi - Your Smart MUT ICT Assistant!**\n\nMy name combines MUT with AI intelligent assistant.\n\n💡 **I can help you with:**\n• 📚 Courses & Qualifications\n• 📝 Admission Requirements\n• 💼 Career Opportunities\n• 🗄️ Database Lessons\n• 📍 MUT Address & Contact\n• 📅 Exam Dates\n• 🎓 Graduation Information\n• 📋 Registration\n• 💰 Bursaries\n• 🏠 Residence\n• 🪪 ID Card Generation\n• 👤 Profile Management\n\nJust ask me anything about MUT ICT! 😊`;
    }
    else if (fuzzyMatch(userMessage, ['help', 'what can i do', 'navigation', 'how to', 'guide'])) {
        reply = `💡 **MUT ICT WEBSITE - HELP & NAVIGATION**\n\n📌 **Available Pages:**\n• 🏠 Home - Latest news\n• 💡 Why ICT? - Benefits\n• 📚 Qualifications - Programmes\n• 💼 Careers - Jobs & salaries\n• 📝 Admission - Entry requirements\n• 🗄️ Database - MySQL lesson\n• 🪪 ID Card - Generate student ID\n• 👤 My Profile - Manage account\n• 🖼️ Image Processing - Edit photos\n\n📞 Still stuck? Call: 031-907-7111 or WhatsApp: 063 885 5903`;
    }
    else {
        reply = `🤔 I'm not sure what you're asking. Let me help you!\n\n💡 **Try asking me about:**\n• 📚 Courses & Qualifications\n• 📝 Admission Requirements\n• 💼 Careers & Salaries\n• 📍 MUT Address & Contact\n• 📅 Exam Dates\n• 🎓 Graduation\n• 💰 Bursaries\n• 🏠 Residence\n• 🪪 ID Card Generation\n\n📞 Contact: 031-907-7111 | WhatsApp: 063 885 5903\n\n💡 Tip: Try keywords like "courses", "admission", "contact", "exam dates" - I understand spelling mistakes! 😊`;
    }
    
    res.json({ reply });
});

// ================= SERVE HTML PAGES =================
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'welcome.html'));
});

app.get('/login.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/welcome.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'welcome.html'));
});

app.get('/index.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/why.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'why.html'));
});

app.get('/course.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'course.html'));
});

app.get('/careers.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'careers.html'));
});

app.get('/admission.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admission.html'));
});

app.get('/database.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'database.html'));
});

app.get('/profile.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'profile.html'));
});

app.get('/image-processing.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'image-processing.html'));
});

app.get('/id-card.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'id-card.html'));
});

// ================= START SERVER =================
app.listen(PORT, () => {
    console.log(`\n╔══════════════════════════════════════════════════════════════╗`);
    console.log(`║                                                              ║`);
    console.log(`║   🚀 MUT ICT SERVER IS RUNNING!                              ║`);
    console.log(`║                                                              ║`);
    console.log(`║   📁 Open in browser: http://localhost:${PORT}                 ║`);
    console.log(`║                                                              ║`);
    console.log(`║   🔐 Demo Login: student@mut.ac.za / mut2026                 ║`);
    console.log(`║                                                              ║`);
    console.log(`║   🗄️  MySQL Database: Connected (mutict)                     ║`);
    console.log(`║                                                              ║`);
    console.log(`║   📧 OTP Email Service: Ready                                ║`);
    console.log(`║                                                              ║`);
    console.log(`║   🤖 Smart Chatbot MUTi is ready!                            ║`);
    console.log(`║      - Answers all website questions                         ║`);
    console.log(`║      - Handles spelling mistakes                            ║`);
    console.log(`║      - Knows about courses, admission, careers, etc.        ║`);
    console.log(`║                                                              ║`);
    console.log(`╚══════════════════════════════════════════════════════════════╝\n`);
});