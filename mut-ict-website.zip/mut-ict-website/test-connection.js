const mysql = require('mysql2');

const db = mysql.createConnection({
    host: '127.0.0.1',
    user: 'root',
    password: '@SpheH2blevel4',
    database: 'mutict'
});

db.connect((err) => {
    if (err) {
        console.error('❌ Connection failed:', err);
        return;
    }
    console.log('✅ Connected to mutict database!');
    
    // Test query
    db.query('SELECT * FROM users', (err, results) => {
        if (err) throw err;
        console.log('Users in database:', results);
        db.end();
    });
});