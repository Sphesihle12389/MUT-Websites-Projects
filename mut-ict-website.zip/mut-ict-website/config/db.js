// config/db.js
const mysql = require('mysql2');
require('dotenv').config();

// Create connection pool
const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'mut_ict_db',
    port: process.env.DB_PORT || 3306,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Convert to promise-based
const promisePool = pool.promise();

// Test connection function
async function testConnection() {
    try {
        const connection = await promisePool.getConnection();
        console.log('✅ MySQL Database connected successfully!');
        connection.release();
        return true;
    } catch (error) {
        console.error('❌ MySQL connection failed:', error.message);
        return false;
    }
}

// Execute query function
async function executeQuery(sql, params = []) {
    try {
        const [rows] = await promisePool.execute(sql, params);
        return rows;
    } catch (error) {
        console.error('Query error:', error);
        throw error;
    }
}

// Get user by email
async function getUserByEmail(email) {
    const users = await executeQuery(
        'SELECT * FROM users WHERE email = ?',
        [email.toLowerCase()]
    );
    return users.length > 0 ? users[0] : null;
}

// Create new user
async function createUser(email, hashedPassword, name, phone) {
    const result = await executeQuery(
        'INSERT INTO users (email, password, name, phone) VALUES (?, ?, ?, ?)',
        [email.toLowerCase(), hashedPassword, name || email.split('@')[0], phone || '']
    );
    return result.insertId;
}

module.exports = {
    promisePool,
    testConnection,
    executeQuery,
    getUserByEmail,
    createUser
};