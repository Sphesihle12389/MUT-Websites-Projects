const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const db = require('../config/db');

// Signup
router.post('/signup', async (req, res) => {
  try {
    const { email, password, phone, name, emailVerified, phoneVerified } = req.body;

    if (!emailVerified || !phoneVerified) {
      return res.json({ success: false, message: "Please verify both email and phone first" });
    }

    db.query(
      "SELECT * FROM otps WHERE email = ? AND verified = TRUE ORDER BY id DESC LIMIT 1",
      [email],
      async (err, otpResults) => {
        if (!otpResults || otpResults.length === 0) {
          return res.json({ success: false, message: "Verify email OTP first" });
        }

        db.query(
          "SELECT * FROM otps WHERE email = ? AND verified = TRUE ORDER BY id DESC LIMIT 1",
          [phone],
          async (err, phoneResults) => {
            if (!phoneResults || phoneResults.length === 0) {
              return res.json({ success: false, message: "Verify phone OTP first" });
            }

            db.query("SELECT * FROM users WHERE email = ?", [email], async (err, users) => {
              if (users && users.length > 0) {
                return res.json({ success: false, message: "Email already registered" });
              }

              const hashedPassword = await bcrypt.hash(password, 10);
              db.query(
                "INSERT INTO users (email, password, phone, name) VALUES (?, ?, ?, ?)",
                [email, hashedPassword, phone, name || email.split('@')[0]],
                (err) => {
                  if (err) {
                    return res.json({ success: false, message: "Registration failed" });
                  }

                  res.json({ success: true, user: { email, name: name || email.split('@')[0], phone } });
                }
              );
            });
          }
        );
      }
    );
  } catch (err) {
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// Login
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  db.query("SELECT * FROM users WHERE email = ?", [email], async (err, users) => {
    if (!users || users.length === 0) {
      return res.json({ success: false, message: "Invalid credentials" });
    }

    const user = users[0];
    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) {
      return res.json({ success: false, message: "Invalid credentials" });
    }

    res.json({ 
      success: true, 
      user: { email: user.email, name: user.name || user.email.split('@')[0], phone: user.phone } 
    });
  });
});

// Logout
router.post('/logout', (req, res) => {
  res.json({ success: true });
});

module.exports = router;